
public class Makiroll3 {

	public static int main(String[] args) {
		return 3;
	}
}
