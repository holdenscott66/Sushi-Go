
public class Pudding {

	public static void main(String[] args) {
		

	}

}
