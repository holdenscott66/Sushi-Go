
public class Dumpling {

	public static int main(String[] args) {
		return 1;
	}
}