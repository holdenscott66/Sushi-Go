
public class Makiroll2 {

	public static int main(String[] args) {
		return 2;
	}
}